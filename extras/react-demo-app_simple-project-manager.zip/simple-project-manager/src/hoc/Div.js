
const Div = (props) => props.children

export default Div;

